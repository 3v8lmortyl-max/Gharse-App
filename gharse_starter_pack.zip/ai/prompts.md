# AI Prompt Examples for Gharse

- "Generate a study plan for class 9 CBSE science."
- "Give project ideas for 10th-grade students to build from home."
- "Create an explainer on how solar panels work for students."

(Add more as app grows.)